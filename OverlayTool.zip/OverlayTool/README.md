# OverlayTool

Dylib overlay cho iOS: viền 7 màu, menu bật/tắt, FPS, ngày & giờ, chế độ sáng/tối.

## Build trên GitHub
1. Tạo repo mới trên GitHub, upload toàn bộ nội dung thư mục này (giữ nguyên cấu trúc, nhánh `main`).
2. Vào tab **Actions** → chọn **Build OverlayTool.dylib** → **Run workflow**.
3. Khi xong, mở run đó và tải artifact `OverlayTool` (bên trong có `OverlayTool.dylib`).

## Sử dụng
- Nút ⚙️ nổi trên màn hình: chạm để mở menu, kéo để di chuyển.
- Bật/tắt từng tính năng trong menu; trạng thái được lưu lại.

## Lưu ý
- Chỉ dùng cho app của bạn hoặc app bạn được phép chỉnh sửa.
- Không dùng để lách anti-cheat hoặc tạo lợi thế trong game online.
